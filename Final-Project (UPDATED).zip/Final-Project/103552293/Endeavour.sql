CREATE DATABASE Endeavour;
USE Endeavour;

CREATE TABLE users (
    user_id INT NOT NULL AUTO_INCREMENT,
    email VARCHAR(127),
    password VARCHAR(255),
    first_name CHAR(20),
    last_name CHAR(20),
    PRIMARY KEY(user_id)
);

CREATE TABLE events (
    event_id INT NOT NULL AUTO_INCREMENT,
    organizer_name CHAR(30),
    city CHAR(10),
    category CHAR(15),
    event_name VARCHAR(40),
    date VARCHAR(15),
    time TIME,
    total_tickets INT,
    PRIMARY KEY(event_id)
);

CREATE TABLE user_tickets (
    user_id INT,
    event_id INT,
    tickets INT
);

/* Inserting dummy values in the server*/
/*Users table */
INSERT INTO users VALUES(1,'admin@gmail.com','adminpass', 'Sir', 'Admin');
/*Events table */
INSERT INTO events VALUES(1,'Endeavour','Adelaide','Entertainment','Launch Party','2022-05-03','15:00',50), (2,'Microsoft','Sydney','Education','Seminar','2022-05-03','20:00',100), (3,'Australian Govt','Melbourne','Information','Media Talkshow','2022-05-03','08:00',500),(4,'Ansh Singh','Adelaide','Education','Lecture','2022-05-06','08:00',150);
