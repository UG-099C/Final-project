function getSession() {
   var xhttp = new XMLHttpRequest();
   xhttp.onreadystatechange = function() {
      if(this.readyState == 4 && this.status >= 401) {
         alert("You need to login to access this page!");
         window.location.replace("index.html");
      }
   };
   xhttp.open("GET", "/loggedin", true);
   xhttp.setRequestHeader("Content-type", "application/json");
   xhttp.send();
}

function getSessionMain() {
   var xhttp = new XMLHttpRequest();
   xhttp.onreadystatechange = function() {
      if(this.readyState == 4 && this.status == 200) {
         window.location.replace("index_loggedin.html");
      }
   };
   xhttp.open("GET", "/loggedin", true);
   xhttp.setRequestHeader("Content-type", "application/json");
   xhttp.send();
}

function login() {
   let user = {
      email: document.getElementById("email").value,
      password: document.getElementById("password").value
   }
   var xhttp = new XMLHttpRequest();
   xhttp.onreadystatechange = function() {
      if (this.readyState == 4 && this.status == 200) {
         console.log("Login Success");
         alert("Login Successful");
         if(user.email == "admin@gmail.com" && user.password == "adminpass")
            window.location.replace("index_adminlogin.html");
         else
            window.location.replace("index_loggedin.html");
      }
      else if (this.readyState == 4 && this.status >= 400) {
         console.log("Login fail");
         alert("login failed. Incorrect email/password.");
         window.location.replace("index.html");
      }
   };
   xhttp.open("POST", "/login", true);
   xhttp.setRequestHeader("Content-type", "application/json");
   xhttp.send(JSON.stringify(user));
}

function editUsers() {
   var xhttp = new XMLHttpRequest();
   xhttp.onreadystatechange = function() {
       if (this.readyState == 4 && this.status == 200) {
         const users = JSON.parse(this.responseText);
         showUserInfo(users);
         console.log(users);
      }
      if(this.readyState == 4 && this.status >= 400) {
         console.log("Error getting user information");
      }
   };
   xhttp.open("GET", "/getUsers", true);
   xhttp.setRequestHeader("Content-type", "application/json");
   xhttp.send();
}

function showUserInfo(users) {
   let text = "";
   for (let i = 0; i < users.length; i++) {
      text += "<tr>";
      text += ("<th scope='row'>"+users[i].user_id+"</th>");
      text += ("<td>"+users[i].email+"</td>");
      text += ("<td>"+users[i].first_name+"</td>");
      text += ("<td>"+users[i].last_name+"</td>");
      text += "</tr>";
   }
   document.getElementById("usersDetails").innerHTML = text;
}

function editEvents() {
   var xhttp = new XMLHttpRequest();
   xhttp.onreadystatechange = function() {
       if (this.readyState == 4 && this.status == 200) {
         const events = JSON.parse(this.responseText);
         showEvents(events);
      }
      if(this.readyState == 4 && this.status >= 400) {
         console.log("Error getting events information");
      }
   };
   xhttp.open("GET", "/getEvents", true);
   xhttp.setRequestHeader("Content-type", "application/json");
   xhttp.send();
}

function showEvents(events) {
   let text = "";
   console.log(events);
   for (let i = 0; i < events.length; i++) {
      text += "<tr>";
      text += ("<th scope='row'>"+events[i].event_id+"</th>");
      text += ("<td>"+events[i].event_name+"</td>");
      text += ("<td>"+events[i].organizer_name+"</td>");
      text += ("<td>"+events[i].date+"</td>");
      text += "</tr>";
   }
   document.getElementById("eventsDetails").innerHTML = text;
}

function deleteUser() {
   var user = document.getElementById("delUser").value;
   var xhttp = new XMLHttpRequest();
          xhttp.onreadystatechange = function() {
              if (this.readyState == 4 && this.status == 200) {
               alert("User deleted!");
               editUsers();
              }
              if(this.readyState == 4 && this.status >= 400) {
               alert("Error deleting user! Try again!");
              }
          };
          xhttp.open("POST", "/deleteUser", true);
          xhttp.setRequestHeader("Content-type", "application/json");
          xhttp.send(JSON.stringify({ userId:user }));
}

function deleteEvent() {
   var event = document.getElementById("delEvent").value;
   var xhttp = new XMLHttpRequest();
          xhttp.onreadystatechange = function() {
              if (this.readyState == 4 && this.status == 200) {
               alert("Event deleted!");
               editEvents();

              }
              if(this.readyState == 4 && this.status >= 400) {
               alert("Error deleting event! Try again!");
              }
          };
          xhttp.open("POST", "/deleteEvent", true);
          xhttp.setRequestHeader("Content-type", "application/json");
          xhttp.send(JSON.stringify({ eventId:event }));
}

function openTicketsPage() {
   window.location.replace("viewTickets.html");
}

function loadTickets() {
   var xhttp = new XMLHttpRequest();
   xhttp.onreadystatechange = function() {
      if (this.readyState == 4 && this.status == 200) {
            const tickets = JSON.parse(this.responseText);
            createTickets(tickets);
      }
   };
   xhttp.open("GET", "/viewTickets", true);
   xhttp.setRequestHeader("Content-type", "application/json");
   xhttp.send();
}

function createTickets (tickets) {
   let text = "";
   if(tickets.length == 0) {
      alert("You have not registered for any events yet!");
   }
    for (let i = 0; i < tickets.length; i++) {
        text += "<div class='card col mx-5 my-3'>";
        text += "<div class='card-body'>";
        text += ("<h5 class='card-title'>"+tickets[i].event_name + "</h5>");
        text += "</div>";
        text += "<ul class='list-group list-group-flush'>";
        text += ("<li class='list-group-item'>" + "Organizer Name : " + tickets[i].organizer_name + "</li>");
        text += ("<li class='list-group-item'>" + "City : " + tickets[i].city + "</li>");
        text += ("<li class='list-group-item'>" + "Category : " + tickets[i].category + "</li>");
        text += ("<li class='list-group-item'>" + "Date : " + tickets[i].date + "</li>");
        text += ("<li class='list-group-item'>" + "Time : " + tickets[i].time + "</li>");
        text += "</ul>";
        text += "<div class='card-body'>";
        text += "</div >";
        text += "</div>";
    }
    document.getElementById("events2").innerHTML = text;
}

function logout() {
   var xhttp = new XMLHttpRequest();
   xhttp.onreadystatechange = function() {
      if (this.readyState == 4 && this.status == 200) {
         alert("Successfully logged out");
         window.location.replace("index.html");
      }

      else if (this.readyState == 4 && this.status >= 400) {
         alert("Logout Error");
         window.location.replace("index.html");
      }

   };
   xhttp.open("POST", "/logout", true);
   xhttp.setRequestHeader("Content-type", "application/json");
   xhttp.send(JSON.stringify({nothing:"empty"}));
}

function signup() {
   let user = {
      email: document.getElementById("signupEmail").value,
      password: document.getElementById("signupPassword").value,
      fname: document.getElementById("signupFname").value,
      lname: document.getElementById("signupLname").value
   }
   var xhttp = new XMLHttpRequest();
   xhttp.onreadystatechange = function() {
      if (this.readyState == 4 && this.status == 200) {
         alert("Signup Successful");
         window.location.replace("index.html");
      }

      else if (this.readyState == 4 && this.status >= 400)
         alert("Signup failed. User with email already exists.");
   };
   xhttp.open("POST", "/register", true);
   xhttp.setRequestHeader("Content-type", "application/json");
   xhttp.send(JSON.stringify(user));
}

function confirmChanges() {
   let userInfo = {};
   if(document.getElementById("newEmail").value)
      userInfo.email = document.getElementById("newEmail").value;
   if(document.getElementById("newPassword").value)
      userInfo.password = document.getElementById("newPassword").value;
   if(document.getElementById("newFname").value)
      userInfo.fname = document.getElementById("newFname").value;
   if(document.getElementById("newLname").value)
      userInfo.lname = document.getElementById("newLname").value;
   var xhttp = new XMLHttpRequest();
   xhttp.onreadystatechange = function() {
      if (this.readyState == 4 && this.status == 200) {
         alert("Changes Successful");
      }
      else if (this.readyState == 4 && this.status == 401) {
         alert("You need to log in to change user information!");
      }
      else if (this.readyState == 4 && this.status >= 400) {
         alert("Changes failed");
      }

   };
   xhttp.open("POST", "/editUserInfo", true);
   xhttp.setRequestHeader("Content-type", "application/json");
   xhttp.send(JSON.stringify(userInfo));
}

function accSettings() {
   window.location.replace("account_settings.html");
}

function getPopularEvents() {
  var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
     if (this.readyState == 4 && this.status == 200) {
        const info = JSON.parse(this.responseText);
        fillEventBox(info);
     }
  };
  xhttp.open("GET", "/getPopularEvents",true);
  xhttp.send();
}
function fillEventBox(events) {
   let text = "";
   if(events.length == 0) {
      text = "<p class='text-center'>You have not registered for any events yet. Look at events at the Events page or browse the top 4 biggest events at the home page!</p>"
   }
    for (let i = 0; i < 3; i++) {
        text += "<div class='card col mx-5 my-3'>";
        text += "<div class='card-body'>";
        text += ("<h5 class='card-title'>"+events[i].event_id+"-"+events[i].event_name + "</h5>");
        text += "</div>";
        text += "<ul class='list-group list-group-flush'>";
        text += ("<li class='list-group-item'>" + "Organizer Name : " + events[i].organizer_name + "</li>");
        text += ("<li class='list-group-item'>" + "City : " + events[i].city + "</li>");
        text += ("<li class='list-group-item'>" + "Category : " + events[i].category + "</li>");
        text += ("<li class='list-group-item'>" + "Date : " + events[i].date + "</li>");
        text += ("<li class='list-group-item'>" + "Time : " + events[i].time + "</li>");
        text += ("<li class='list-group-item'>" + "Tickets : " + events[i].total_tickets + "</li>");
        text += "</ul>";
        text += "<div class='card-body'>";
        text += "<button type='button' onclick='getSession()' class='btn btn-primary' data-bs-toggle='modal' data-bs-target='#registerModal'>Register</button>";
        text += "</div >";
        text += "</div>";
    }
    document.getElementById("events").innerHTML = text;
}

function registerForEvent() {
   let ticket = {
      email: document.getElementById("registerEmail").value,
      tickets: document.getElementById("numTickets").value,
      fname: document.getElementById("registerFname").value,
      lname: document.getElementById("registerLname").value,
      event_id: document.getElementById("eId").value
   }
   console.log(ticket);
   var xhttp = new XMLHttpRequest();
   xhttp.onreadystatechange = function() {
      if (this.readyState == 4 && this.status == 200) {
         alert("Registered for the Event!");
         getPopularEvents();
      }

      else if (this.readyState == 4 && this.status >= 400) {
         alert("Error registering for event");
      }

   };
   xhttp.open("POST", "/registerForEvent", true);
   xhttp.setRequestHeader("Content-type", "application/json");
   xhttp.send(JSON.stringify(ticket));
};