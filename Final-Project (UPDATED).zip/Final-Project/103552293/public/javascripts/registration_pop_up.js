function register() {
    var temp = document.getElementById("navbar");
    temp.style.color = "black";
    temp.style.opacity = "0.2";
    var temp = document.getElementById("event");
    temp.style.color = "black";
    temp.style.opacity = "0.2";
    var temp = document.getElementById("footer");
    temp.style.color = "black";
    temp.style.opacity = "0.2";
    var popup = document.getElementById("popup");
    popup.style.display = "block";
    popup.style.zIndex = 1000;
    popup.style.position = "fixed";
};
function mainRegister() {
    var temp = document.getElementById("navbar");
    temp.style.color = "black";
    temp.style.opacity = "1";
    var temp = document.getElementById("event");
    temp.style.color = "black";
    temp.style.opacity = "1";
    var temp = document.getElementById("footer");
    temp.style.color = "black";
    temp.style.opacity = "1";
    var popup = document.getElementById("popup");
    popup.style.display = "none";
};