var express = require('express');
var router = express.Router();

router.get('/', function(req, res, next) {
  res.render('index');
})

// router.get('/?', function(req, res, next) {
//   alert("Logged in Successfully!");
//   res.render('index_loggedin');
// })

module.exports = router;
//MAIN PAGE REQUESTS

router.get('/getPopularEvents', function(req, res, next) {
  req.pool.getConnection(function(err,connection) {
    if (err) {
      res.sendStatus(500);
      return;
    }
    var query = "SELECT event_name,total_tickets,city,category,organizer_name,date,time,event_id FROM events ORDER BY total_tickets DESC";
    connection.query(query, function(err, rows, fields) {
    connection.release();
      if (err) {
        console.log(err);
        res.sendStatus(500);
      }
      res.json(rows);
    });
  });
});

router.post('/login', function(req, res, next) {
  req.pool.getConnection(function(err,connection) {
    if (err) {
      return "error";
    }
    var query = "SELECT email,password,user_id FROM users";
    connection.query(query, function(err, rows, fields) {
    connection.release();
      if (err) {
        console.log(err);
        return;
      }
      if('email' in req.body && 'password' in req.body) {
        let val = setUsers(rows,req.body.email,req.body.password);
        if(val == 200) {
          users = Object.values(JSON.parse(JSON.stringify(rows)));
          for(let i=0; i<users.length;i++) {
            if(users[i].email == req.body.email)
              req.session.user = users[i].user_id;
          }
          res.sendStatus(200);
          return;
        }
        else {
          console.log("Bad login");
          res.sendStatus(401);
          return;
        }
      }
      else {
        console.log("Bad request");
        res.sendStatus(400);
        return;
      }
    });
  });
});

function setUsers(rows,email,password) {
  users = Object.values(JSON.parse(JSON.stringify(rows)));
  for(let i=0; i<users.length; i++) {
    if(email === users[i].email && password === users[i].password ) {
      return 200;
    }
  }
  return 400;
};

router.post('/register', function(req, res, next) {
  if('email' in req.body && 'password' in req.body && 'fname' in req.body && 'lname' in req.body) {
    req.pool.getConnection(function(err,connection) {
      if (err) {
        return "error";
      }
      var query = "SELECT email FROM users";
      connection.query(query, function(err, rows, fields) {
        if (err) {
          console.log(err);
          return;
        }
          let val = checkUsers(rows,req.body.email);
          if(val == false) {
            console.log("User already exists with given email");
            res.sendStatus(403);
            return;
          }
          else {
            var query = "INSERT INTO users (email,password,first_name,last_name) VALUES (?,?,?,?)";
            connection.query(query,[req.body.email,req.body.password,req.body.fname,req.body.lname], function(err, rows, fields) {
            connection.release();
            if (err) {
              console.log(err);
              res.sendStatus(500);
              return;
            }
            });
            console.log("User created");
            res.sendStatus(200);
            return;
          }
      });
    });
  }
  else {
    console.log("Bad request");
    res.sendStatus(400);
  }
});

function checkUsers(rows,email) {
  users = Object.values(JSON.parse(JSON.stringify(rows)));
  for(let i=0; i<users.length; i++) {
    if(email === users[i].email)
      return false;
  }
  return true;
};

router.post('/logout', function(req, res, next) {
  if('user' in req.session) {
    delete req.session.user;
    res.sendStatus(200);
    res.redirect('/');
  }
  else {
    alert("You need to be signed in to logout!")
    res.sendStatus(401);
    return;
  }
});

router.get('/loggedin', function(req, res, next) {
  if('user' in req.session)
    res.sendStatus(200);
  else
    res.sendStatus(401);
});

router.post('/editUserInfo', function(req, res, next) {
  if('user' in req.session) {
    if('email' in req.body || 'password' in req.body || 'fname' in req.body || 'lname' in req.body) {
      req.pool.getConnection(function(err,connection) {
        if (err) {
          return "error";
        }
        if('email' in req.body) {
          var query = "UPDATE users SET email=? WHERE user_id=?";
          connection.query(query,[req.body.email,req.session.user], function(err, rows, fields) {
          if (err) {
            console.log(err);
            return;
          }});
        }
        if('password' in req.body) {
          var query = "UPDATE users SET password=? WHERE user_id=?";
          connection.query(query,[req.body.password,req.session.user], function(err, rows, fields) {
          if (err) {
            console.log(err);
            return;
          }});
        }
        if('fname' in req.body) {
          var query = "UPDATE users SET first_name=? WHERE user_id=?";
          connection.query(query,[req.body.fname, req.session.user], function(err, rows, fields) {
          if (err) {
            console.log(err);
            return;
          }});
        }
        if('lname' in req.body) {
          var query = "UPDATE users SET last_name=? WHERE user_id=?";
          connection.query(query,[req.body.lname,req.session.user], function(err, rows, fields) {
          if (err) {
            console.log(err);
            return;
          }});
        }
        connection.release();
        console.log("Changes successful");
        res.sendStatus(200);
      });
      }
    else {
      console.log("Bad request");
      res.sendstatus(400);
    }
  }
  else {
    alert("You need to be signed in to edit acocunt settings!");
    res.sendStatus(401);
    return;
  }
});

router.get("/viewTickets", function(req, res, next) {
  req.pool.getConnection(function (err, connection) {
    if (err) {
      res.sendStatus(500);
      return;
    }
    let query = 'SELECT e.event_name,e.total_tickets,e.city,e.category,e.organizer_name,e.date,e.time,e.event_id FROM events e INNER JOIN user_tickets u on e.event_id = u.event_id WHERE user_id=?';
    connection.query(query,[req.session.user], function (err, rows, fields) {
      connection.release();
      if (err) {
        res.sendStatus(500);
        return;
      }
      res.json(rows);
    });
  });
});

router.get("/getUsers", function(req, res, next) {
  req.pool.getConnection(function (err, connection) {
    if (err) {
      res.sendStatus(500);
      return;
    }
    let query = 'SELECT user_id,email,first_name,last_name FROM users';
    connection.query(query,[req.session.user], function (err, rows, fields) {
      connection.release();
      if (err) {
        res.sendStatus(500);
        return;
      }
      res.json(rows);
    });
  });
});

router.post('/deleteUser', function(req, res, next) {
  if('user' in req.session) {
    req.pool.getConnection(function (err, connection) {
      if (err) {
        res.sendStatus(500);
        return;
      }
      let query = 'DELETE FROM user_tickets WHERE user_id=?';
      connection.query(query,[req.body.userId], function (err, rows, fields) {
        if (err) {
          res.sendStatus(400);
          return;
        } });
        let query2 = 'DELETE FROM users WHERE user_id=?';
        connection.query(query2,[req.body.userId], function (err, rows, fields) {
          if (err) {
            res.sendStatus(400);
            return;
          } });
          connection.release();
          res.sendStatus(200);
      });
  }
  else {
    console.log("Bad request");
    res.sendStatus(400);
  }

});

router.post('/deleteEvent', function(req, res, next) {
  req.pool.getConnection(function (err, connection) {
    if (err) {
      res.sendStatus(500);
      return;
    }
    let query = 'DELETE FROM events WHERE event_id=?';
    connection.query(query,[req.body.eventId], function (err, rows, fields) {
      connection.release();
      if (err) {
        res.sendStatus(400);
        return;
      }
      res.sendStatus(200);
    });
  });
});

router.post('/registerForEvent', function(req, res, next) {
  req.pool.getConnection(function (err, connection) {
    if (err) {
      res.sendStatus(400);
      return;
    }
    let query = 'INSERT INTO user_tickets (user_id,event_id,tickets) VALUES (?,?,?)';
    connection.query(query,[req.session.user,req.body.event_id,req.body.tickets], function (err, rows, fields) {
      connection.release();
      if (err) {
        res.sendStatus(400);
        return;
      }
      res.sendStatus(200);
    });
  });
});

router.post('/addEvent', function(req, res, next) {
  req.pool.getConnection(function (err, connection) {
    if (err) {
      res.sendStatus(400);
      return;
    }
    let query = 'INSERT INTO events(organizer_name,city,category,event_name,date,time,total_tickets) VALUES (?,?,?,?,?,?,?)';
    connection.query(query,[req.body.organizer_name,req.body.city,req.body.category,req.body.event_name,req.body.date,req.body.time,req.body.tickets], function (err, rows, fields) {
      connection.release();
      if (err) {
        console.log("Not working for some reaosn");
        res.sendStatus(400);
        return;
      }
      res.sendStatus(200);
    });
  });
});

//MAIN PAGE REQUESTS END HERE

//EVENTS PAGE REQUESTS
router.get('/getEvents', function (req, res, next) {
  req.pool.getConnection(function (err, connection) {
    if (err) {
      res.sendStatus(500);
      return;
    }
    let query = 'SELECT * FROM events';
    connection.query(query, function (err, rows, fields) {
      connection.release();
      if (err) {
        res.sendStatus(500);
        return;
      }
      res.json(rows);
    });
  });
});

router.get('/getEventsByCity/:city', function (req, res, next) {
  req.pool.getConnection(function (err, connection) {
    if (err) {
      res.sendStatus(500);
      return;
    }
    let query = `SELECT * FROM events WHERE city='${req.params.city}'`;
    connection.query(query, function (err, rows, fields) {
      connection.release();
      if (err) {
        res.sendStatus(500);
        return;
      }
      res.json(rows);
    });
  });
});

router.get('/getCities', function (req, res, next) {
  req.pool.getConnection(function (err, connection) {
    if (err) {
      res.sendStatus(500);
      return;
    }
    let query = 'SELECT DISTINCT(city) FROM events ORDER BY city';
    connection.query(query, function (err, rows, fields) {
      connection.release();
      if (err) {
        res.sendStatus(500);
        return;
      }
      res.json(rows);
    });
  });
});
//EVENT PAGE REQUESTS END HERE

//CALENDAR AND HOST EVENT REQUESTS START HERE
router.get('/events', function(req, res, next) {
  res.render('Events');
});
router.get('/event-registration', function(req, res, next) {
  res.render('event-registration');
});
router.get('/host-event', function(req, res, next) {
  res.render('host-event');
});
router.get('/about', function(req, res, next) {
  res.render('about');
});
router.get('/contact', function(req, res, next) {
  res.render('contact');
});
router.post('/contact-request', function(req, res, next) {
  console.log(req.body);
  res.redirect('/contact');
});
router.post('/host-created-event', function(req, res, next) {
  console.log(req.body);
  res.redirect('/');
});
router.get('/calendar', function(req, res, next) {
  res.render('calendar');
});