function displayEvents () {
    let activities = document.querySelector(".form-select");
    activities.addEventListener("change", () => {
        if (activities.value == "Please Select An Option") {
            displayEvents();
        }
        else {
            displayEventsByCity(activities.value);
        }
    });
    const xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
            const jsonPost = this.responseText;
            const events = JSON.parse(jsonPost);
            createTable(events);
        }
    };
    xhttp.open("GET", "/getEvents");
    xhttp.send();
    const xwhttp = new XMLHttpRequest();
    xwhttp.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
            const jsonPost = this.responseText;
            const cities = JSON.parse(jsonPost);
            addOptions(cities);
        }
    };
    xwhttp.open("GET", "/getCities");
    xwhttp.send();
}

function getSession() {
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
       if(this.readyState == 4 && this.status >= 401) {
          alert("You need to login to access this page!");
          window.location.replace("index.html");
       }
    };
    xhttp.open("GET", "/loggedin", true);
    xhttp.setRequestHeader("Content-type", "application/json");
    xhttp.send();
 }

function displayEventsByCity (city) {
    const xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
            const jsonPost = this.responseText;
            const events = JSON.parse(jsonPost);
            createTable(events);
        }
    };
    xhttp.open("GET", `/getEventsByCity/${city}`);
    xhttp.send();
}
function createTable (events) {
    let text = "";
    for (let i = 0; i < events.length; i++) {
        text += "<div class='card col mx-5 my-3'>";
        text += "<div class='card-body'>";
        text += ("<h5 class='card-title'>" + events[i].event_id + " - " + events[i].event_name + "</h5>");
        text += "</div>";
        text += "<ul class='list-group list-group-flush'>";
        text += ("<li class='list-group-item'>" + "Organizer Name : " + events[i].organizer_name + "</li>");
        text += ("<li class='list-group-item'>" + "City : " + events[i].city + "</li>");
        text += ("<li class='list-group-item'>" + "Category : " + events[i].category + "</li>");
        text += ("<li class='list-group-item'>" + "Date : " + events[i].date + "</li>");
        text += ("<li class='list-group-item'>" + "Time : " + events[i].time + "</li>");
        text += ("<li class='list-group-item'>" + "Number Of People Allowed : " + events[i].total_tickets + "</li>");
        text += "</ul>";
        text += "<div class='card-body'>";
        text += "<button type='button' onclick='getSession()' class='btn btn-primary' data-bs-toggle='modal' data-bs-target='#registerModal'>Register</button>";
        text += "</div >";
        text += "</div>";
    }
    document.getElementById("event-row").innerHTML = text;
}

function registerForEvent() {
    let ticket = {
       email: document.getElementById("registerEmail").value,
       tickets: document.getElementById("numTickets").value,
       fname: document.getElementById("registerFname").value,
       lname: document.getElementById("registerLname").value,
       event_id: document.getElementById("eId").value
    }
    console.log(ticket);
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
       if (this.readyState == 4 && this.status == 200) {
          alert("Registered for the Event!");
       }

       else if (this.readyState == 4 && this.status >= 400) {
          alert("Error registering for event");
       }

    };
    xhttp.open("POST", "/registerForEvent", true);
    xhttp.setRequestHeader("Content-type", "application/json");
    xhttp.send(JSON.stringify(ticket));
 };

function addOptions (cities) {
    let text = "<option selected>All</option>";
    for (let i = 0; i < cities.length; i++) {
        text += `<option value='${cities[i].city}'>${cities[i].city}</option>`;
    }
    document.querySelector(".form-select").innerHTML = text;
}

function openTicketsPage() {
    window.location.replace("viewTickets.html");
 }

 function accSettings() {
    window.location.replace("account_settings.html");
 }

 function logout() {
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
       if (this.readyState == 4 && this.status == 200) {
          alert("Successfully logged out");
          window.location.replace("index.html");
       }

       else if (this.readyState == 4 && this.status >= 400) {
          alert("Logout Error");
          window.location.replace("index.html");
       }

    };
    xhttp.open("POST", "/logout", true);
    xhttp.setRequestHeader("Content-type", "application/json");
    xhttp.send(JSON.stringify({nothing:"empty"}));
 }