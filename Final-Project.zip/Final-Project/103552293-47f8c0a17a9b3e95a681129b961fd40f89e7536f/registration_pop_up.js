function register() {
    var temp = document.getElementById("navbar");
    temp.style.backgroundColor = "black";
    temp.style.opacity = "0.2";
    var temp = document.getElementById("event");
    temp.style.color = "black";
    temp.style.opacity = "0.2";
    var temp = document.getElementById("footer");
    temp.style.color = "black";
    temp.style.opacity = "0.2";
    var popup = document.getElementById("popup");
    popup.style.display = "block";
    popup.style.zIndex = 1000;
    popup.style.position = "fixed";
};